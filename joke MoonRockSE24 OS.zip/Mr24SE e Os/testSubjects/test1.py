class a:
     b = 10
amongus = a()
