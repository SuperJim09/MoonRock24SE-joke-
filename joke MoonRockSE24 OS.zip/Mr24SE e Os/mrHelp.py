def main():
    print("Type the help section you want to read:")
    print(" OS MANUAL ")
    print(" Homepage Keyboard Control ")
    print(" DOS MANUAL ")
    command = input()
