import os
while True:
    command = input("Error run a programm!")
    if command.startswith("call"):
        name = command[5:]
        os.system('call ' + name)
    else:
        print("what are you doing...")
