import MoonRock24SE

MoonRock24SE.activator()
